<?php
// Connect to the database
include('../include/connections.php');
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['admin_nickname'])){
    $admin_id = $_SESSION['admin_id'];

$query = "SELECT * FROM Admin WHERE admin_id = $admin_id";
$result = $conn->query($query);

if ($result->num_rows > 0) {
$data = $result->fetch_assoc();
}
echo '<div class="container">Hello: ' . $data['admin_nickname'] . '</div>';

    echo '<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="home.php">Your Website Name</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <select class="form-select" onchange="location = this.value;">
                    <option value="home.php">Home</option>
                    <option value="business.php" selected>Business</option>
                    <option value="technology.php">Technology</option>
                    <option value="sports.php">Sports</option>
                    <option value="beauty.php">Beauty</option>
                    <option value="society.php">Society</option>
                    <option value="todayinworld.php">Today in World</option>
                </select>
            </div>
        </div>
    </nav>
</div>';

echo '<div class="container">
    <div class="row">
        <div class="col-md-6 d-flex">
            <a class="btn btn-primary"  style="margin-right:8px" href="create.php">Create a new Post</a>
            <a class="btn btn-primary" style="margin-right:8px"  href="#">Profile</a>
            <a class="btn btn-primary" style="margin-right:8px"  href="response.php">Response</a>

        </div>
        <div class="col-md-6 text-end">
                    <a class="btn btn-danger " href="admin_logout.php">Logout</a>
        </div>
    </div>
</div>';

}

//Shorten text for display content
function shorten_text($text, $max_length)
{
    if (mb_strlen($text, 'UTF-8') > $max_length) {
        $shorten_text = mb_substr($text, 0, $max_length, 'UTF-8');
        $shorten_text .= '...';
        return $shorten_text;
    }
    return $text;
}
?>

<?php
// Pagination 
$record_per_page = 6;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $record_per_page;

// Retrieve approved records from the database
$query = "SELECT * FROM Post, Category WHERE Post.category_id = Category.category_id AND Category.category_name = 'Business' AND status = 1";
$result = $conn->query($query);

if ($result === false) {
    echo "Error: " . $conn->error;
    exit;
}

// Calculate the total number of approved posts
$total_approved_posts = $result->num_rows;

// Calculate the total number of pages based on the number of approved posts and the records per page
$total_pages = ceil($total_approved_posts / $record_per_page);

// Retrieve records for the current page
$query = "SELECT * FROM Post, Category WHERE Post.category_id = Category.category_id AND Category.category_name = 'Business' AND status = 1
          LIMIT $offset, $record_per_page";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo "<div class='container'>";
    echo "<div class='row'>";
    while ($data = $result->fetch_assoc()) {
        echo "<div class='col-md-4 mb-4'>";
        echo "<div class='card' style='height:550px;' >";
        echo "<a href='read.php?post_id=" . $data['post_id'] . "'>" . $data['post_title'] . "</a>"; //Title display
        echo "<img style='height:300px' class='item' src='" . $data['post_image'] . "' class='card-img-top' alt='Post Image' width=100%>"; //Image displayed
        echo "<div class='card-body'>";
        echo "<p class='card-text'>" . shorten_text($data['post_content'], 100) . "</p>";

        echo "<div class='d-flex justify-content-between align-items-center'>";
        echo "<p class='mb-0'>" . $data['category_name'] . "</p>";
        echo "<p class='mb-0'>Rating: " . $data['rate'] . "</p>";
        echo "</div>";

        if ($data['status'] == 0) {
            echo '<span class="badge bg-warning">Pending</span>';
        } else {
            $statusLabel = ($data['status'] == 1) ? 'Approved' : 'Rejected';
            echo '<span class="badge bg-success">' . $statusLabel . '</span>';
            echo "<a href='delete.php?post_id=" . $data['post_id'] . "' class='btn btn-danger btn-sm ms-2'>Delete</a>";

        }

        if ($data['status'] == 0) {
            echo '<form method="POST" action="update_status.php" class="mt-2">';
            echo '<input type="hidden" name="post_id" value="' . $data['post_id'] . '">';
            echo '<button type="submit" name="status" value="approve" class="btn btn-success btn-sm">Approve</button>';
            echo '<button type="submit" name="status" value="reject" class="btn btn-danger btn-sm ms-2">Reject</button>';
            echo '</form>';
        }

        if (isset($_SESSION['admin_id'])) {
            if ($_SESSION['admin_id'] == $data['admin_id']){
                echo "<a href='update.php?post_id=" . $data['post_id'] . "'>" . "Update</a>";
            }
        }

      // Rating form
      $currentPage = isset($_GET['page']) ? $_GET['page'] : '1';
      // Rating form
      echo "<form method='POST' action='business.php?post_id=" . $data['post_id'] . "&page=$currentPage' class='mt-2'>";      echo "<div class='input-group'>";
      echo "<select class='form-select' name='post_rating'>";
      echo "<option>--- Rating ---</option>";
      for ($i = 1; $i <= 5; $i++) {
          echo "<option value='$i'>$i</option>";
      }
      echo "</select>";
      echo "<button type='submit' name='rate_submit' class='btn btn-primary'>Rate</button>";
      echo "</div>";
      echo "</form>";

      echo "</div>"; // card-body
      echo "</div>"; // card
      echo "</div>"; // col-md-4
  }
  echo "</div>"; // row
  echo "</div>"; // container

  // Pagination links
   // Pagination links
   $query = "SELECT COUNT(*) as total FROM Post WHERE category_id = '4'";
   $result = $conn->query($query);
   $row = $result->fetch_assoc();
   $total_pages = ceil($row['total'] / $record_per_page);

   echo "<div class='container'>";
   echo "<div class='row'>";
   echo "<div class='col-md-12'>";
   echo "<ul class='pagination'>";
   for ($i = 1; $i <= $total_pages; $i++) {
       echo "<li class='page-item";
       if ($i == $page) {
           echo " active";
       }
       echo "'><a class='page-link' href='?page=" . $i . "'>" . $i . "</a></li>";
   }
   echo "</ul>";
   echo "</div>";
   echo "</div>";
   echo "</div>";

} else {
  echo 'Error: No data found !';
}

// Handle rating submission
if (isset($_POST['rate_submit'])) {
  $post_id = $_GET['post_id'];
  $post_rating = $_POST['post_rating'];

  // Update the rating of the post in the database
  $query = "UPDATE Post SET rate = $post_rating WHERE post_id = $post_id";
  $result = $conn->query($query);

  if ($result == TRUE) {
      echo 'Post rated successfully';
      header ('Location: home.php');
  } else {
      echo 'Failed to rate the post: ' . $conn->error;
  }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
</html>